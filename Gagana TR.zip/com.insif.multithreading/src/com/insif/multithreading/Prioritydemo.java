package com.insif.multithreading;

class MyTask extends Thread{
	public void main() {
		System.out.println(Thread.currentThread().getName()+""+Thread.current);
	}
}
public class Prioritydemo {
public static void main(String[] args) {
	MyTask t1=new MyTask();
	
}

}
