package com.insif.multithreading;
//demo for Multithreading
class Eclipse extends Thread{
	public void run() {
		System.out.println("Eclipse id:"+""+Thread.currentThread().getId());
	}
}

class Onenote extends Thread{
	public void run() {
		System.out.println("Onenote id:"+""+Thread.currentThread().getId());
	}
}

class Chrome extends Thread{
	public void run() {
		System.out.println("Chrome id:"+""+Thread.currentThread().getId());
	}
}

public class Extendingthreading {
public static void main(String[] args) {
	Eclipse e=new Eclipse();
	e.start();
	Onenote n=new Onenote();
	n.start();
	Chrome c=new Chrome();
	c.start();
}
}
