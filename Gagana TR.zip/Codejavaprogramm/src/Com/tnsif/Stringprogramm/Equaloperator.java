package Com.tnsif.Stringprogramm;

public class Equaloperator {
public static void main(String[] args) {
	String s1="Kavana";
	String s2="Kavana";
	String s3=new String("Kavana");
	String s4="Gagana";
	
	System.out.println(s1==s2);
	System.out.println(s1==s3);
	System.out.println(s1==s4);

}

}
