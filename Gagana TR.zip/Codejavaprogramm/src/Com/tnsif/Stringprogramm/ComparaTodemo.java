package Com.tnsif.Stringprogramm;

public class ComparaTodemo {
public static void main(String[] args) {
	String s1="harshitha";
	String s2="harshitha";
	String s3="gagana";
	
	System.out.println(s1.compareTo(s2));
	System.out.println(s1.compareTo(s3));
	System.out.println(s3.compareTo(s1));

}

}
