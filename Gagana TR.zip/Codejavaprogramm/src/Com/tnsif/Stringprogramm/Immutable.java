package Com.tnsif.Stringprogramm;

public class Immutable {
public static void main(String[] args) {
	String s1="Sachin";
	String s2=s1;
	String s3=s2;
	
	System.out.println("Before modfication:");
	System.out.println("s1:"+s1);
	System.out.println("s2:"+s2);
	System.out.println("s3:"+s3);
	
	s1="tendulkar";
	
	System.out.println("After modfication:");
	System.out.println("s1:"+s1);
	System.out.println("s2:"+s2);
	System.out.println("s3:"+s3);

	
}

}
