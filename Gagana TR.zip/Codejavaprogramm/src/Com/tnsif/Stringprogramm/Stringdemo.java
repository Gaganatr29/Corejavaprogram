package Com.tnsif.Stringprogramm;

public class Stringdemo {
public static void main(String[] args) {
	
	//creating a string
	String s="Hello Java programming";
	
	//length()
	System.out.println("Length:"+s.length());
	
	//charAt()
	System.out.println("Character at the index 6:"+s.charAt(6));
	
	//touppercase and lower
	System.out.println("Upper case:"+s.toUpperCase());
	System.out.println("Lower case:"+s.toLowerCase());
	
	//contains
	System.out.println(s.contains("Java"));
	
	//startwith
	System.out.println(s.startsWith("word"));
	
	//endswith
	System.out.println(s.endsWith("hello"));
	
	System.out.println(s.substring(6,10));
	System.out.println(s.replace("Java","Python"));
	
}

}
