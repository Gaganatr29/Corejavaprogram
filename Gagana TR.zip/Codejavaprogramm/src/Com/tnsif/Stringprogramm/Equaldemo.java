package Com.tnsif.Stringprogramm;

public class Equaldemo {
public static void main(String[] args) {
	String s1="Gagana";
	String s2=new String("Gagana");
	String s3="Gagana";
	String s4="Sneha";
	
	System.out.println(s1.equals(s2));
	System.out.println(s1.equals(s3));
	System.out.println(s1.equals(s4));
	
	System.out.println(s1.equalsIgnoreCase(s2));
	System.out.println(s1.equalsIgnoreCase(s3));
	System.out.println(s1.equalsIgnoreCase(s4));
}

}
