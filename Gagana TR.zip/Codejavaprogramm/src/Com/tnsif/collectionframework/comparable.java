package Com.tnsif.collectionframework;

import java.util.ArrayList;
import java.util.Collections;

class Student implements Comparable<Student>{
	int marks;
	String name;
	public Student(int marks,String name) {
		super();
		this.marks=marks;
		this.name=name;
		
	}
	@Override
	public int compareTo(Student o) {
		return this.marks-o.marks;	
		
	
	}
	@Override
	public String toString() {
		return "Student [marks=" + marks + ", name=" + name + "]";
	}
	
}



public class comparable {
public static void main(String[] args) {
	ArrayList<Student> s=new ArrayList<>();
	s.add(new Student(85,"Rahul"));
	s.add(new Student(65,"Harshitha"));
	s.add(new Student(20,"Kavana"));
	s.add(new Student(90,"Gagana"));
	Collections.sort(s);
	System.out.println(s);
}

}

