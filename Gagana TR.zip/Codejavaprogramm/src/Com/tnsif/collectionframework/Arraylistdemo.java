package Com.tnsif.collectionframework;

import java.util.ArrayList;

public class Arraylistdemo {
public static void main(String[] args) {
ArrayList<String> p=new ArrayList<>();
p.add("Laptop");
p.add("Headphone");
p.add(null);
p.add("Mobile");
p.add("Headphone");
p.add("Headphone");
p.add("Headphone");
p.add("Headphone");
p.add("Headphone");
p.add("Headphone");
System.out.println(p);
System.out.println("product 1 :"+ p.get(1));
System.out.println("contains mobile ?"+p.contains("mobile"));
System.out.println(p.size());
p.remove("headphone");
System.out.println(p);
for(String i:p) {
	System.out.println(i);
}
}

}
