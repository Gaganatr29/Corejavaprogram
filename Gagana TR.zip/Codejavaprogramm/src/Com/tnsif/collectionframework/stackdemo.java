package Com.tnsif.collectionframework;

import java.util.Stack;


public class stackdemo {
public static void main(String[] args) {
	Stack<String> s=new Stack<>();
	s.push("Laptop");
	s.push("Mobile");
	s.push("Keyboard");
	s.push("Headphones");
	
	 System.out.println(s);
	 System.out.println("Top element: "+s.peek());
	 System.out.println("position of mobile: "+s.search("Mobile"));
	 System.out.println("contains Laptop? " +s.contains("Laptop"));
	 
	 System.out.println("Size: " +s.size());
	 System.out.println("Removed:"+s.pop());
	 System.out.println(s);
	 
	 for(String  i :s) {
		 System.out.println(i);
	 }
	 
}

}
