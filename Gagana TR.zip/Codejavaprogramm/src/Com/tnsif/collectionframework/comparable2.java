package Com.tnsif.collectionframework;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class person{
	String name;
	int age;
	public person(String name,int age) {
		super();
		this.name=name;
		this.age=age;
	}
	void display() {
		System.out.println("person [name=" + name + ", age=" + age );
	}
}
class NameComparator implements Comparator<person>{

	@Override
	public int compare(person o1, person o2) {
		return o1.name.compareTo(o2.name);
	}
	
}
class Agecomparator implements Comparator<person>{
	@Override
	public int compare(person o1, person o2) {
		return Integer.compare(o1.age,o2.age);
	}
	}


public class comparable2 {
	public static void main(String[] args) {
		List<person> p=new ArrayList<>();
		p.add(new person("Rahul",85));
		p.add(new person("Harshitha",65));
		p.add(new person("Kavana",20));
		p.add(new person("Gagana",90));
		
		Collections.sort(p,new NameComparator());
		System.out.println("sorted by name");
		for(person s:p) {
			s.display();
			
		}
		
		Collections.sort(p,new Agecomparator());
		System.out.println("sorted by name");
		for(person s:p) {
			s.display();

	}
	}



}

