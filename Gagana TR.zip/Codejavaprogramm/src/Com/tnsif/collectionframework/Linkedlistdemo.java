package Com.tnsif.collectionframework;

import java.util.LinkedList;


public class Linkedlistdemo {
public static void main(String[] args) {
	LinkedList<String> h=new LinkedList<>();
	h.add("Google");
	h.add("Youtube");
	h.add("Github");
	h.add("Python");
	h.add("Java");
	System.out.println(h);
	
	h.addFirst("sql");
	System.out.println(h);
	
	h.addLast("postgresql");
	System.out.println("First "+h.peekFirst());
	System.out.println("removed:"+h.pollFirst());
	System.out.println(h);
	
	

}

}
