package Com.tnsif.collectionframework;

import java.util.HashSet;


public class Skillcomparison {
public static void main(String[] args) {
	HashSet<String> Javateam=new HashSet<>();
	Javateam.add("Java");
	Javateam.add("Sql");
	Javateam.add("Html");
	Javateam.add("DBMS");
	
	HashSet<String> Pythonteam=new HashSet<>();
	Pythonteam.add("Python");
	Pythonteam.add("Git");
	Pythonteam.add("AMS");
	Pythonteam.add("Docker");
	
	HashSet<String> common=(HashSet<String>) Javateam.clone();
	     System.out.println(common);
	     
	     //keep only skill available in both team
	     common.retainAll(Pythonteam);
	     System.out.println("Common skills : "+common);
	     
	     //create a another copy of javateam skill
	 	HashSet<String> onlyjava =(HashSet<String>) Javateam.clone();
	 	System.out.println(onlyjava);

	     

	
	



	
}
}
