package Com.tnsif.ExceptionHandling;

public class StringIndex {
public static void main(String[] args) {
	String name="Java";
	try {
		System.out.println(name.charAt(0));
		System.out.println(name.charAt(3));
		System.out.println(name.charAt(9));
		System.out.println("Welcome");
	}
	catch(Exception e) {
		System.out.println(e);
	}
	System.out.println("program continue.......");	
	}
		
	}
