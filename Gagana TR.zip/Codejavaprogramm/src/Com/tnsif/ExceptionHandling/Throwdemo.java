package Com.tnsif.ExceptionHandling;

public class Throwdemo {
static void checkAge(int age) {
	if (age<18) {
		throw new ArithmeticException("Student is not eligible for voting");
	}
	System.out.println("student is eligible for voting");
}
public static void main(String[] args) {
	try {
		checkAge(16);
}
	catch(ArithmeticException e) {
	System.out.println(e.getMessage());
	}

}
}
