package Com.tnsif.ExceptionHandling;

public class Throwdemo2 {
static void checkPassword (String password){
	if(password.length()<6) {
		throw new IllegalArgumentException("password is to0 short..");
	}
	System.out.println("password accepted");
}

public static void main(String[] args) {
	try {
		checkPassword("1234567345");
	}
	catch(IllegalArgumentException i) {
		System.out.println(i.getMessage());
	}
}


}
