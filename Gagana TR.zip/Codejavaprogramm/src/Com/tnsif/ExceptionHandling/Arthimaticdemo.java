package Com.tnsif.ExceptionHandling;

public class Arthimaticdemo {
public static void main(String[] args) {
	int salary=80000;
	int workingday=20;
	int bonusDays=4;
	
	try {
		int dailysalary=salary/workingday;
		System.out.println("Daily salary:"+dailysalary);
		
		int bonusperday=salary/0;
		System.out.println("Bonus:"+(bonusperday*bonusDays));
		}
	catch(ArithmeticException e) {
		System.out.println("cannot calculate salary bonus...");
		System.out.println(e);
		}
	System.out.println("salary processing completed....");	
}

}
