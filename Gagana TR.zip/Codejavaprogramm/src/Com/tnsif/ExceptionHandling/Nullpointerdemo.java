package Com.tnsif.ExceptionHandling;

public class Nullpointerdemo {
public static void main(String[] args) {
	String employeename ="gagana";
	String department = null;
	String designation="developer";
	try {
		System.out.println("employeename "+employeename);
		System.out.println("employe designation" +designation);
		System.out.println("employee department"+department.toLowerCase());
		}
	catch(NullPointerException N) {
		System.out.println("Employee department is missing");
		System.out.println(N);
		}
	System.out.println("employee data analysis completed");

}

}