package Com.tnsif.ExceptionHandling;

public class ExceptionHandling {
static void Login(String username,String password)throws Exception{
	if(username.equals("admin")) {
		throw new Exception("Invalid username");
	}
	System.out.println("login succrssfully");
	}
public static void main(String[] args) {
	try {
		Login("admin","111");
	}
	catch(Exception s) {
		System.out.println(s.getMessage());
}
	System.out.println("Login process completed");
}

}
