package Com.tnsif.ExceptionHandling;

public class WithoutExceptionHandling {
public static void main(String[] args) {
	System.out.println("Goodmorning all");
	int a =90;
	int b=0;
	System.out.println("Welcome to java");
	System.out.println(b/a);
	System.out.println("Hello worid");
}
}
