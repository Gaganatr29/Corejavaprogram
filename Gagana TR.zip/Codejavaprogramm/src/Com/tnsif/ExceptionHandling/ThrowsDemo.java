package Com.tnsif.ExceptionHandling;

public class ThrowsDemo {
static void calculate(int a,int b)throws ArithmeticException{
	int result =a/b;
	System.out.println("Result:"+result);
}
public static void main(String[] args) {
	try {
		calculate(10,8);
	}
	catch(ArithmeticException e) {
		System.out.println();
	}
}

}
